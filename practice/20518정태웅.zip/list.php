<?php
    try{
        $pdo = new PDO('mysql:host = localhost; dbname = test1; charset = utf-8', 'root', '');
        $pdo -> setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }
    catch(PDOException $Exception){
        die("접속오류: ".$Exception -> getMessage());
    }

    $id     = $_POST["id"];
    $pw     = $_POST["pw"];
    $name   = $_POST["name"];
    $phone_number = $_POST["phone_number"];

    $sql = "INSERT INTO member (id, pw, name, phone_number) VALUES ($id, $pw, $name, $phone_number)";
    print $sql;
    mysql_query($sql, $pdo);

    print $id."<br>";
    print $pw."<br>";
    print $name."<br>";
    print $phone_number."<br>";
?>